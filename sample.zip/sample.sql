
CREATE TABLE IF NOT EXISTS `sample` (
  
  `Id` int(255) NOT NULL,
  `State` varchar(255) NOT NULL,
  `City` varchar(255) NOT NULL,
  `Dates` varchar(255) NOT NULL,
  `Value` int(255) NOT NULL
  
) ;

